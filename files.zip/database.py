"""
Database initialization and management module.
Handles SQLite database operations for vehicle health monitoring.
"""

import sqlite3
import os
from datetime import datetime
from contextlib import contextmanager


class Database:
    """SQLite database manager for vehicle health monitoring system."""
    
    def __init__(self, db_path='vehicle_health.db'):
        """
        Initialize database connection.
        
        Args:
            db_path (str): Path to SQLite database file
        """
        self.db_path = db_path
        self.init_database()
    
    @contextmanager
    def get_connection(self):
        """
        Context manager for database connections.
        
        Yields:
            sqlite3.Connection: Database connection
        """
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def init_database(self):
        """Initialize database tables if they don't exist."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Vehicle sensor data table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vehicle_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    temperature REAL NOT NULL,
                    vibration REAL NOT NULL,
                    battery_voltage REAL NOT NULL,
                    fuel_level REAL NOT NULL,
                    vhi REAL DEFAULT 100.0,
                    prediction INTEGER DEFAULT 0,
                    severity TEXT DEFAULT 'Low',
                    rul_estimate REAL DEFAULT 0.0,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Alerts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alert_type TEXT NOT NULL,
                    message TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    temperature REAL,
                    vibration REAL,
                    battery_voltage REAL,
                    fuel_level REAL,
                    is_resolved INTEGER DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    resolved_at DATETIME
                )
            ''')
            
            conn.commit()
    
    def insert_sensor_data(self, temperature, vibration, battery_voltage, 
                          fuel_level, vhi, prediction, severity, rul_estimate):
        """
        Insert sensor data into database.
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
            vhi (float): Vehicle Health Index
            prediction (int): Fault prediction (0-3)
            severity (str): Severity level (Low/Medium/High)
            rul_estimate (float): Remaining Useful Life estimate
        
        Returns:
            int: ID of inserted record
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO vehicle_data 
                (temperature, vibration, battery_voltage, fuel_level, vhi, prediction, severity, rul_estimate)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (temperature, vibration, battery_voltage, fuel_level, vhi, prediction, severity, rul_estimate))
            return cursor.lastrowid
    
    def insert_alert(self, alert_type, message, severity, temperature=None, 
                    vibration=None, battery_voltage=None, fuel_level=None):
        """
        Insert alert into database.
        
        Args:
            alert_type (str): Type of alert (Temperature, Battery, Vibration, etc.)
            message (str): Alert message
            severity (str): Severity level (Low/Medium/High)
            temperature (float, optional): Associated temperature reading
            vibration (float, optional): Associated vibration reading
            battery_voltage (float, optional): Associated battery voltage
            fuel_level (float, optional): Associated fuel level
        
        Returns:
            int: ID of inserted alert
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO alerts 
                (alert_type, message, severity, temperature, vibration, battery_voltage, fuel_level)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (alert_type, message, severity, temperature, vibration, battery_voltage, fuel_level))
            return cursor.lastrowid
    
    def get_recent_data(self, limit=20):
        """
        Retrieve recent sensor data.
        
        Args:
            limit (int): Number of records to retrieve
        
        Returns:
            list: List of sensor data records
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM vehicle_data 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    
    def get_latest_data(self):
        """
        Retrieve the latest sensor data record.
        
        Returns:
            dict: Latest sensor data record or None
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM vehicle_data 
                ORDER BY timestamp DESC 
                LIMIT 1
            ''')
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_recent_alerts(self, limit=10):
        """
        Retrieve recent alerts.
        
        Args:
            limit (int): Number of alerts to retrieve
        
        Returns:
            list: List of alert records
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM alerts 
                ORDER BY created_at DESC 
                LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
    
    def resolve_alert(self, alert_id):
        """
        Mark an alert as resolved.
        
        Args:
            alert_id (int): ID of the alert to resolve
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE alerts 
                SET is_resolved = 1, resolved_at = ? 
                WHERE id = ?
            ''', (datetime.now(), alert_id))
    
    def get_statistics(self, hours=24):
        """
        Get statistics for dashboard.
        
        Args:
            hours (int): Time period in hours
        
        Returns:
            dict: Statistics including averages, min, max values
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT 
                    AVG(temperature) as avg_temp,
                    AVG(vibration) as avg_vibration,
                    AVG(battery_voltage) as avg_battery,
                    AVG(fuel_level) as avg_fuel,
                    MIN(temperature) as min_temp,
                    MAX(temperature) as max_temp,
                    MIN(vhi) as min_vhi,
                    AVG(vhi) as avg_vhi,
                    COUNT(*) as total_records
                FROM vehicle_data 
                WHERE timestamp > datetime('now', '-' || ? || ' hours')
            ''', (hours,))
            row = cursor.fetchone()
            return dict(row) if row else None