"""
Model training script for fault prediction.
Generates synthetic data and trains Random Forest classifier.
Run this script before starting the Flask application.
"""

import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib


class SyntheticDataGenerator:
    """Generate synthetic vehicle sensor data for model training."""
    
    def __init__(self, random_state=42):
        """
        Initialize data generator.
        
        Args:
            random_state (int): Random seed for reproducibility
        """
        np.random.seed(random_state)
    
    def generate_normal_data(self, n_samples=500):
        """Generate normal operating condition data."""
        return {
            'temperature': np.random.normal(80, 8, n_samples),
            'vibration': np.random.normal(1.0, 0.3, n_samples),
            'battery_voltage': np.random.normal(12.5, 0.3, n_samples),
            'fuel_level': np.random.normal(60, 20, n_samples),
            'label': 0  # Normal
        }
    
    def generate_overheating_data(self, n_samples=300):
        """Generate engine overheating data."""
        return {
            'temperature': np.random.normal(110, 10, n_samples),
            'vibration': np.random.normal(1.2, 0.4, n_samples),
            'battery_voltage': np.random.normal(12.2, 0.4, n_samples),
            'fuel_level': np.random.normal(50, 20, n_samples),
            'label': 1  # Engine Overheating
        }
    
    def generate_battery_issue_data(self, n_samples=250):
        """Generate battery issue data."""
        return {
            'temperature': np.random.normal(75, 10, n_samples),
            'vibration': np.random.normal(1.1, 0.3, n_samples),
            'battery_voltage': np.random.normal(11.0, 0.5, n_samples),
            'fuel_level': np.random.normal(65, 20, n_samples),
            'label': 2  # Battery Issue
        }
    
    def generate_vibration_issue_data(self, n_samples=300):
        """Generate abnormal vibration data."""
        return {
            'temperature': np.random.normal(85, 8, n_samples),
            'vibration': np.random.normal(2.8, 0.5, n_samples),
            'battery_voltage': np.random.normal(12.3, 0.3, n_samples),
            'fuel_level': np.random.normal(55, 20, n_samples),
            'label': 3  # Abnormal Vibration
        }
    
    def generate_complete_dataset(self):
        """
        Generate complete synthetic dataset.
        
        Returns:
            pd.DataFrame: Combined dataset with all conditions
        """
        datasets = []
        
        # Generate data for each condition
        datasets.append(self._dict_to_dataframe(self.generate_normal_data()))
        datasets.append(self._dict_to_dataframe(self.generate_overheating_data()))
        datasets.append(self._dict_to_dataframe(self.generate_battery_issue_data()))
        datasets.append(self._dict_to_dataframe(self.generate_vibration_issue_data()))
        
        # Combine all datasets
        df = pd.concat(datasets, ignore_index=True)
        
        # Shuffle dataset
        df = df.sample(frac=1).reset_index(drop=True)
        
        return df
    
    @staticmethod
    def _dict_to_dataframe(data):
        """Convert data dictionary to DataFrame."""
        n_samples = len(data['temperature'])
        return pd.DataFrame({
            'temperature': data['temperature'],
            'vibration': data['vibration'],
            'battery_voltage': data['battery_voltage'],
            'fuel_level': data['fuel_level'],
            'label': [data['label']] * n_samples
        })


class ModelTrainer:
    """Train and save the fault prediction model."""
    
    # Class labels
    LABELS = {
        0: 'Normal',
        1: 'Engine Overheating',
        2: 'Battery Issue',
        3: 'Abnormal Vibration'
    }
    
    def __init__(self):
        """Initialize model trainer."""
        self.model = None
        self.scaler = None
        self.feature_names = ['temperature', 'vibration', 'battery_voltage', 'fuel_level']
    
    def train(self, X_train, y_train):
        """
        Train Random Forest classifier.
        
        Args:
            X_train (np.ndarray): Training features
            y_train (np.ndarray): Training labels
        
        Returns:
            dict: Training results with accuracy metrics
        """
        print("Training Random Forest Classifier...")
        
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        
        self.model.fit(X_train, y_train)
        
        # Calculate training accuracy
        train_accuracy = self.model.score(X_train, y_train)
        print(f"Training Accuracy: {train_accuracy:.4f}")
        
        # Feature importance
        feature_importance = dict(zip(self.feature_names, self.model.feature_importances_))
        print(f"Feature Importance: {feature_importance}")
        
        return {
            'accuracy': train_accuracy,
            'feature_importance': feature_importance
        }
    
    def predict(self, X):
        """
        Make predictions.
        
        Args:
            X (np.ndarray): Input features
        
        Returns:
            np.ndarray: Predictions
        """
        if self.model is None:
            raise ValueError("Model not trained yet")
        return self.model.predict(X)
    
    def predict_proba(self, X):
        """
        Get prediction probabilities.
        
        Args:
            X (np.ndarray): Input features
        
        Returns:
            np.ndarray: Prediction probabilities
        """
        if self.model is None:
            raise ValueError("Model not trained yet")
        return self.model.predict_proba(X)
    
    def save_model(self, model_path='models/fault_prediction_model.pkl'):
        """
        Save trained model to file.
        
        Args:
            model_path (str): Path to save model
        """
        os.makedirs(os.path.dirname(model_path) if os.path.dirname(model_path) else '.', exist_ok=True)
        joblib.dump(self.model, model_path)
        print(f"Model saved to {model_path}")
    
    def load_model(self, model_path='models/fault_prediction_model.pkl'):
        """
        Load trained model from file.
        
        Args:
            model_path (str): Path to model file
        
        Returns:
            bool: True if loaded successfully
        """
        if os.path.exists(model_path):
            self.model = joblib.load(model_path)
            print(f"Model loaded from {model_path}")
            return True
        return False


def main():
    """Main training script."""
    print("=" * 60)
    print("Vehicle Health Monitoring - Model Training")
    print("=" * 60)
    
    # Generate synthetic data
    print("\nGenerating synthetic training data...")
    generator = SyntheticDataGenerator()
    df = generator.generate_complete_dataset()
    
    # Save synthetic data
    os.makedirs('dataset', exist_ok=True)
    df.to_csv('dataset/synthetic_data.csv', index=False)
    print(f"Synthetic data saved to dataset/synthetic_data.csv")
    print(f"Dataset shape: {df.shape}")
    print(f"\nClass distribution:\n{df['label'].value_counts().sort_index()}")
    
    # Prepare training data
    X = df[['temperature', 'vibration', 'battery_voltage', 'fuel_level']].values
    y = df['label'].values
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # Train model
    trainer = ModelTrainer()
    results = trainer.train(X_train, y_train)
    
    # Test accuracy
    test_accuracy = trainer.model.score(X_test, y_test)
    print(f"Test Accuracy: {test_accuracy:.4f}")
    
    # Save model
    os.makedirs('models', exist_ok=True)
    trainer.save_model('models/fault_prediction_model.pkl')
    
    print("\n" + "=" * 60)
    print("Training completed successfully!")
    print("=" * 60)


if __name__ == '__main__':
    main()