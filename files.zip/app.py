"""
Flask backend for AI-Based Vehicle Health Monitoring System.
Provides REST API endpoints for sensor data collection and health prediction.
"""

from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from datetime import datetime
import os
import sys
import traceback

from database import Database
from model import FaultPredictionModel
from utils import VehicleHealthCalculator, AlertSystem, RULEstimator, DataValidator


# Initialize Flask app
app = Flask(__name__, 
           template_folder='templates',
           static_folder='static')
CORS(app)

# Initialize components
db = Database('vehicle_health.db')
ml_model = FaultPredictionModel()
vhi_calculator = VehicleHealthCalculator()
alert_system = AlertSystem(vhi_calculator)
rul_estimator = RULEstimator()


@app.route('/')
def index():
    """Serve the dashboard HTML."""
    return render_template('dashboard.html')


@app.route('/static/<path:filename>')
def serve_static(filename):
    """Serve static files."""
    return send_from_directory('static', filename)


# ==================== SENSOR DATA ENDPOINTS ====================

@app.route('/api/sensor-data', methods=['POST'])
def receive_sensor_data():
    """
    Receive sensor data from IoT device.
    
    Expected JSON:
    {
        "temperature": 85.5,
        "vibration": 1.2,
        "battery_voltage": 12.5,
        "fuel_level": 60.0
    }
    
    Returns:
        JSON with prediction, VHI, alerts, and health status
    """
    try:
        # Parse request
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No JSON data provided'
            }), 400
        
        # Extract sensor values
        temperature = data.get('temperature')
        vibration = data.get('vibration')
        battery_voltage = data.get('battery_voltage')
        fuel_level = data.get('fuel_level')
        
        # Validate data
        is_valid, error_msg = DataValidator.validate_sensor_data(
            temperature, vibration, battery_voltage, fuel_level
        )
        if not is_valid:
            return jsonify({
                'success': False,
                'error': error_msg
            }), 400
        
        # Make ML prediction
        prediction_result = ml_model.predict(temperature, vibration, battery_voltage, fuel_level)
        if not prediction_result['success']:
            return jsonify({
                'success': False,
                'error': prediction_result['error']
            }), 500
        
        prediction = prediction_result['prediction']
        prediction_label = prediction_result['prediction_label']
        confidence = prediction_result['confidence']
        
        # Calculate VHI
        vhi = vhi_calculator.calculate_vhi(temperature, vibration, battery_voltage, fuel_level)
        health_status = vhi_calculator.get_health_status(vhi)
        
        # Classify severity
        severity = vhi_calculator.classify_severity(vhi, prediction)
        
        # Estimate RUL
        rul = rul_estimator.estimate_rul(temperature, vibration, battery_voltage, fuel_level, vhi)
        
        # Generate alerts
        alerts = alert_system.generate_alerts(temperature, vibration, battery_voltage, fuel_level)
        
        # Store in database
        record_id = db.insert_sensor_data(
            temperature=temperature,
            vibration=vibration,
            battery_voltage=battery_voltage,
            fuel_level=fuel_level,
            vhi=vhi,
            prediction=prediction,
            severity=severity,
            rul_estimate=rul
        )
        
        # Store alerts in database
        for alert in alerts:
            db.insert_alert(
                alert_type=alert['type'],
                message=alert['message'],
                severity=alert['severity'],
                temperature=temperature,
                vibration=vibration,
                battery_voltage=battery_voltage,
                fuel_level=fuel_level
            )
        
        # Prepare response
        response = {
            'success': True,
            'record_id': record_id,
            'timestamp': datetime.now().isoformat(),
            'sensor_data': {
                'temperature': round(temperature, 2),
                'vibration': round(vibration, 2),
                'battery_voltage': round(battery_voltage, 2),
                'fuel_level': round(fuel_level, 2)
            },
            'prediction': {
                'label': prediction_label,
                'code': prediction,
                'confidence': round(confidence, 4)
            },
            'vhi': round(vhi, 2),
            'health_status': health_status,
            'severity': severity,
            'rul_estimate_hours': round(rul, 2),
            'alerts': alerts,
            'alert_summary': alert_system.get_alert_summary()
        }
        
        return jsonify(response), 201
    
    except Exception as e:
        print(f"Error in receive_sensor_data: {str(e)}")
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': f'Server error: {str(e)}'
        }), 500


@app.route('/api/dashboard-data', methods=['GET'])
def get_dashboard_data():
    """
    Get recent sensor data for dashboard visualization.
    
    Returns:
        JSON with recent records and statistics
    """
    try:
        limit = request.args.get('limit', 20, type=int)
        
        # Get recent data
        recent_data = db.get_recent_data(limit)
        
        # Get statistics
        stats = db.get_statistics()
        
        # Get latest record
        latest = db.get_latest_data()
        
        # Get recent alerts
        recent_alerts = db.get_recent_alerts(10)
        
        response = {
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'latest': latest,
            'recent_data': recent_data,
            'statistics': stats,
            'recent_alerts': recent_alerts
        }
        
        return jsonify(response), 200
    
    except Exception as e:
        print(f"Error in get_dashboard_data: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==================== ALERT ENDPOINTS ====================

@app.route('/api/alerts', methods=['GET'])
def get_alerts():
    """
    Get recent alerts.
    
    Returns:
        JSON with list of alerts
    """
    try:
        limit = request.args.get('limit', 10, type=int)
        alerts = db.get_recent_alerts(limit)
        
        return jsonify({
            'success': True,
            'alerts': alerts,
            'count': len(alerts)
        }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/alerts/<int:alert_id>/resolve', methods=['PUT'])
def resolve_alert(alert_id):
    """
    Mark an alert as resolved.
    
    Args:
        alert_id (int): ID of the alert to resolve
    
    Returns:
        JSON confirmation
    """
    try:
        db.resolve_alert(alert_id)
        return jsonify({
            'success': True,
            'message': f'Alert {alert_id} marked as resolved'
        }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==================== INFORMATION ENDPOINTS ====================

@app.route('/api/model-info', methods=['GET'])
def get_model_info():
    """
    Get information about the ML model.
    
    Returns:
        JSON with model details
    """
    try:
        model_info = ml_model.get_model_info()
        return jsonify({
            'success': True,
            'model': model_info
        }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """
    Health check endpoint.
    
    Returns:
        JSON status
    """
    return jsonify({
        'success': True,
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'model_loaded': ml_model.model is not None
    }), 200


# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500


if __name__ == '__main__':
    print("=" * 60)
    print("Vehicle Health Monitoring System - Flask Backend")
    print("=" * 60)
    print(f"Starting server at http://localhost:5000")
    print(f"Dashboard: http://localhost:5000")
    print(f"API: http://localhost:5000/api")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)