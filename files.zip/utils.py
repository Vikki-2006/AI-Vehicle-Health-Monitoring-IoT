"""
Utility functions for vehicle health monitoring system.
Includes VHI calculation, alert system, and data validation.
"""

import math
from datetime import datetime


class VehicleHealthCalculator:
    """Calculate Vehicle Health Index (VHI) based on sensor readings."""
    
    # Alert thresholds
    TEMP_NORMAL_MAX = 95
    TEMP_WARNING = 100
    TEMP_CRITICAL = 110
    
    VIBRATION_NORMAL_MAX = 1.8
    VIBRATION_WARNING = 2.5
    VIBRATION_CRITICAL = 3.5
    
    BATTERY_NORMAL_MIN = 12.0
    BATTERY_WARNING = 11.5
    BATTERY_CRITICAL = 11.0
    
    FUEL_WARNING_MIN = 15
    FUEL_CRITICAL_MIN = 5
    
    def __init__(self):
        """Initialize health calculator with baseline VHI of 100."""
        self.baseline_vhi = 100.0
    
    def calculate_vhi(self, temperature, vibration, battery_voltage, fuel_level):
        """
        Calculate Vehicle Health Index (0-100).
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
        
        Returns:
            float: VHI score (0-100)
        """
        vhi = self.baseline_vhi
        
        # Temperature penalty
        if temperature > self.TEMP_CRITICAL:
            vhi -= 40
        elif temperature > self.TEMP_WARNING:
            vhi -= 25
        elif temperature > self.TEMP_NORMAL_MAX:
            vhi -= 10
        
        # Vibration penalty
        if vibration > self.VIBRATION_CRITICAL:
            vhi -= 35
        elif vibration > self.VIBRATION_WARNING:
            vhi -= 20
        elif vibration > self.VIBRATION_NORMAL_MAX:
            vhi -= 8
        
        # Battery penalty
        if battery_voltage < self.BATTERY_CRITICAL:
            vhi -= 30
        elif battery_voltage < self.BATTERY_WARNING:
            vhi -= 15
        elif battery_voltage < self.BATTERY_NORMAL_MIN:
            vhi -= 5
        
        # Fuel level penalty
        if fuel_level < self.FUEL_CRITICAL_MIN:
            vhi -= 25
        elif fuel_level < self.FUEL_WARNING_MIN:
            vhi -= 10
        
        return max(0, min(100, vhi))  # Clamp between 0-100
    
    def get_health_status(self, vhi):
        """
        Get health status based on VHI.
        
        Args:
            vhi (float): Vehicle Health Index
        
        Returns:
            str: Health status (Excellent/Good/Fair/Poor/Critical)
        """
        if vhi >= 80:
            return "Excellent"
        elif vhi >= 60:
            return "Good"
        elif vhi >= 40:
            return "Fair"
        elif vhi >= 20:
            return "Poor"
        else:
            return "Critical"
    
    def classify_severity(self, vhi, prediction):
        """
        Classify fault severity based on VHI and ML prediction.
        
        Args:
            vhi (float): Vehicle Health Index
            prediction (int): ML prediction (0=Normal, 1=Overheating, 2=Battery, 3=Vibration)
        
        Returns:
            str: Severity level (Low/Medium/High)
        """
        if prediction == 0:  # Normal
            return "Low"
        elif vhi >= 60:
            return "Low"
        elif vhi >= 40:
            return "Medium"
        else:
            return "High"


class AlertSystem:
    """Generate alerts based on sensor readings."""
    
    def __init__(self, vhi_calculator):
        """
        Initialize alert system.
        
        Args:
            vhi_calculator (VehicleHealthCalculator): VHI calculator instance
        """
        self.vhi_calc = vhi_calculator
        self.alerts = []
    
    def generate_alerts(self, temperature, vibration, battery_voltage, fuel_level):
        """
        Generate alerts based on sensor readings.
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
        
        Returns:
            list: List of alert dictionaries
        """
        self.alerts = []
        
        # Temperature alerts
        if temperature > self.vhi_calc.TEMP_CRITICAL:
            self.alerts.append({
                'type': 'CRITICAL_TEMPERATURE',
                'message': f'CRITICAL: Engine temperature {temperature}°C - Immediate action required!',
                'severity': 'High',
                'component': 'Engine'
            })
        elif temperature > self.vhi_calc.TEMP_WARNING:
            self.alerts.append({
                'type': 'HIGH_TEMPERATURE',
                'message': f'WARNING: Engine temperature {temperature}°C is elevated',
                'severity': 'Medium',
                'component': 'Engine'
            })
        
        # Vibration alerts
        if vibration > self.vhi_calc.VIBRATION_CRITICAL:
            self.alerts.append({
                'type': 'CRITICAL_VIBRATION',
                'message': f'CRITICAL: Abnormal vibration {vibration} m/s² detected',
                'severity': 'High',
                'component': 'Mechanical'
            })
        elif vibration > self.vhi_calc.VIBRATION_WARNING:
            self.alerts.append({
                'type': 'HIGH_VIBRATION',
                'message': f'WARNING: Vibration level {vibration} m/s² is abnormal',
                'severity': 'Medium',
                'component': 'Mechanical'
            })
        
        # Battery alerts
        if battery_voltage < self.vhi_calc.BATTERY_CRITICAL:
            self.alerts.append({
                'type': 'CRITICAL_BATTERY',
                'message': f'CRITICAL: Battery voltage {battery_voltage}V is critically low',
                'severity': 'High',
                'component': 'Electrical'
            })
        elif battery_voltage < self.vhi_calc.BATTERY_WARNING:
            self.alerts.append({
                'type': 'LOW_BATTERY',
                'message': f'WARNING: Battery voltage {battery_voltage}V is low',
                'severity': 'Medium',
                'component': 'Electrical'
            })
        
        # Fuel level alerts
        if fuel_level < self.vhi_calc.FUEL_CRITICAL_MIN:
            self.alerts.append({
                'type': 'CRITICAL_FUEL',
                'message': f'CRITICAL: Fuel level {fuel_level}% - Refuel immediately',
                'severity': 'High',
                'component': 'Fuel'
            })
        elif fuel_level < self.vhi_calc.FUEL_WARNING_MIN:
            self.alerts.append({
                'type': 'LOW_FUEL',
                'message': f'WARNING: Fuel level {fuel_level}% is low',
                'severity': 'Medium',
                'component': 'Fuel'
            })
        
        return self.alerts
    
    def get_alert_summary(self):
        """
        Get summary of active alerts.
        
        Returns:
            dict: Summary with counts by severity
        """
        summary = {
            'total': len(self.alerts),
            'high': sum(1 for a in self.alerts if a['severity'] == 'High'),
            'medium': sum(1 for a in self.alerts if a['severity'] == 'Medium'),
            'low': sum(1 for a in self.alerts if a['severity'] == 'Low')
        }
        return summary


class RULEstimator:
    """Estimate Remaining Useful Life based on sensor data patterns."""
    
    def __init__(self):
        """Initialize RUL estimator with degradation constants."""
        self.temperature_threshold = 100
        self.vibration_threshold = 2.5
        self.battery_threshold = 11.5
        self.base_rul_hours = 1000
    
    def estimate_rul(self, temperature, vibration, battery_voltage, fuel_level, vhi):
        """
        Estimate Remaining Useful Life in hours.
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
            vhi (float): Vehicle Health Index
        
        Returns:
            float: Estimated RUL in hours
        """
        rul = self.base_rul_hours
        
        # Temperature degradation
        if temperature > self.temperature_threshold:
            temp_excess = temperature - self.temperature_threshold
            rul *= (1 - (temp_excess / 50) * 0.15)
        
        # Vibration degradation
        if vibration > self.vibration_threshold:
            vibration_excess = vibration - self.vibration_threshold
            rul *= (1 - (vibration_excess / 2) * 0.2)
        
        # Battery degradation
        if battery_voltage < self.battery_threshold:
            battery_deficit = self.battery_threshold - battery_voltage
            rul *= (1 - (battery_deficit / 2) * 0.1)
        
        # VHI impact (most significant)
        vhi_factor = vhi / 100
        rul *= vhi_factor
        
        # Fuel level impact (minor)
        if fuel_level < 20:
            rul *= (1 - 0.05)
        
        return max(0, rul)


class DataValidator:
    """Validate sensor data for reasonable values."""
    
    # Valid ranges
    TEMP_MIN, TEMP_MAX = -20, 150
    VIBRATION_MIN, VIBRATION_MAX = 0, 10
    BATTERY_MIN, BATTERY_MAX = 8, 15
    FUEL_MIN, FUEL_MAX = 0, 100
    
    @staticmethod
    def validate_sensor_data(temperature, vibration, battery_voltage, fuel_level):
        """
        Validate sensor data.
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
        
        Returns:
            tuple: (is_valid, error_message)
        """
        errors = []
        
        if not isinstance(temperature, (int, float)):
            errors.append("Temperature must be a number")
        elif not (DataValidator.TEMP_MIN <= temperature <= DataValidator.TEMP_MAX):
            errors.append(f"Temperature must be between {DataValidator.TEMP_MIN} and {DataValidator.TEMP_MAX}")
        
        if not isinstance(vibration, (int, float)):
            errors.append("Vibration must be a number")
        elif not (DataValidator.VIBRATION_MIN <= vibration <= DataValidator.VIBRATION_MAX):
            errors.append(f"Vibration must be between {DataValidator.VIBRATION_MIN} and {DataValidator.VIBRATION_MAX}")
        
        if not isinstance(battery_voltage, (int, float)):
            errors.append("Battery voltage must be a number")
        elif not (DataValidator.BATTERY_MIN <= battery_voltage <= DataValidator.BATTERY_MAX):
            errors.append(f"Battery voltage must be between {DataValidator.BATTERY_MIN} and {DataValidator.BATTERY_MAX}")
        
        if not isinstance(fuel_level, (int, float)):
            errors.append("Fuel level must be a number")
        elif not (DataValidator.FUEL_MIN <= fuel_level <= DataValidator.FUEL_MAX):
            errors.append(f"Fuel level must be between {DataValidator.FUEL_MIN} and {DataValidator.FUEL_MAX}")
        
        if errors:
            return False, "; ".join(errors)
        return True, ""