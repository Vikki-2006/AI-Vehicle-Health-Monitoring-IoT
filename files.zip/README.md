# AI-Based Vehicle Health Monitoring System Using IoT Sensors

A production-grade Python Flask-based vehicle health monitoring system with machine learning fault prediction, real-time dashboard, and comprehensive alert management.

## 🚀 Features

### Core Functionality
- **Real-time IoT Sensor Monitoring**: Temperature, Vibration, Battery Voltage, Fuel Level
- **ML-powered Fault Prediction**: Random Forest classifier for 4 fault conditions
- **Vehicle Health Index (VHI)**: 0-100 scale health assessment
- **Remaining Useful Life (RUL) Estimation**: Predictive maintenance recommendations
- **Intelligent Alert System**: Severity-based alerts (Low/Medium/High)
- **Modern Web Dashboard**: Real-time visualization with Chart.js

### Advanced Features
- Synthetic data generation for model training
- Alert logging and resolution tracking
- Historical data visualization
- Responsive mobile-friendly UI
- RESTful API endpoints
- Production-ready error handling

## 📋 Project Structure
