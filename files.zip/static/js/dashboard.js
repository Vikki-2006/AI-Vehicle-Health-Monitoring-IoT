/**
 * Vehicle Health Monitoring Dashboard
 * Real-time visualization and data management
 */

const API_BASE = '/api';
const REFRESH_INTERVAL = 5000; // 5 seconds
const CHART_HISTORY = 20; // Number of data points to display

// Global state
let dashboardState = {
    latestData: null,
    recentData: [],
    charts: {},
    refreshInterval: null,
    connectionStatus: 'connected'
};

// ==================== INITIALIZATION ====================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Dashboard initialized');
    initializeCharts();
    refreshData();
    setupEventListeners();
    dashboardState.refreshInterval = setInterval(refreshData, REFRESH_INTERVAL);
    updateFooter();
});

// ==================== CHART INITIALIZATION ====================

function initializeCharts() {
    // Color palette
    const colors = {
        primary: '#2563eb',
        secondary: '#6366f1',
        success: '#10b981',
        warning: '#f59e0b',
        danger: '#ef4444'
    };

    const commonOptions = {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                labels: {
                    color: '#cbd5e1',
                    font: { size: 12, weight: '600' }
                }
            }
        },
        scales: {
            x: {
                grid: { color: 'rgba(255, 255, 255, 0.1)' },
                ticks: { color: '#cbd5e1' }
            },
            y: {
                grid: { color: 'rgba(255, 255, 255, 0.1)' },
                ticks: { color: '#cbd5e1' }
            }
        }
    };

    // Temperature Chart
    const tempCtx = document.getElementById('tempChart').getContext('2d');
    dashboardState.charts.temperature = new Chart(tempCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Temperature (°C)',
                data: [],
                borderColor: colors.danger,
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: colors.danger,
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: { ...commonOptions }
    });

    // Vibration Chart
    const vibCtx = document.getElementById('vibChart').getContext('2d');
    dashboardState.charts.vibration = new Chart(vibCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Vibration (m/s²)',
                data: [],
                borderColor: colors.secondary,
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: colors.secondary,
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: { ...commonOptions }
    });

    // Battery Chart
    const batteryCtx = document.getElementById('batteryChart').getContext('2d');
    dashboardState.charts.battery = new Chart(batteryCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Battery Voltage (V)',
                data: [],
                borderColor: colors.success,
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: colors.success,
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: { ...commonOptions }
    });

    // VHI Chart
    const vhiCtx = document.getElementById('vhiChart').getContext('2d');
    dashboardState.charts.vhi = new Chart(vhiCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Vehicle Health Index',
                data: [],
                borderColor: colors.primary,
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: colors.primary,
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: { ...commonOptions }
    });

    // VHI Gauge (Doughnut Chart)
    const gaugeCtx = document.getElementById('vhiGauge').getContext('2d');
    dashboardState.charts.gauge = new Chart(gaugeCtx, {
        type: 'doughnut',
        data: {
            labels: ['Health', 'Degradation'],
            datasets: [{
                data: [100, 0],
                backgroundColor: ['#10b981', 'rgba(255, 255, 255, 0.1)'],
                borderColor: '#1e293b',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false }
            }
        }
    });
}

// ==================== DATA REFRESH ====================

function refreshData() {
    fetch(`${API_BASE}/dashboard-data`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                dashboardState.latestData = data.latest;
                dashboardState.recentData = data.recent_data;
                updateDashboard(data);
                updateConnectionStatus(true);
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            updateConnectionStatus(false);
        });
}

// ==================== DASHBOARD UPDATE ====================

function updateDashboard(data) {
    if (!data.latest) return;

    const latest = data.latest;

    // Update sensor values
    updateSensorCard('tempValue', 'tempBar', 'tempStatus', latest.temperature, 0, 150, '°C', 100);
    updateSensorCard('vibValue', 'vibBar', 'vibStatus', latest.vibration, 0, 5, 'm/s²', 2.5);
    updateSensorCard('batteryValue', 'batteryBar', 'batteryStatus', latest.battery_voltage, 8, 15, 'V', 12);
    updateSensorCard('fuelValue', 'fuelBar', 'fuelStatus', latest.fuel_level, 0, 100, '%', 100);

    // Update prediction and status
    document.getElementById('vhiScore').textContent = latest.vhi.toFixed(1);
    document.getElementById('healthStatus').textContent = getHealthStatus(latest.vhi);
    document.getElementById('prediction').textContent = 'Normal';
    document.getElementById('severity').textContent = latest.severity;
    document.getElementById('severity').className = `value severity-badge ${latest.severity.toLowerCase()}`;
    document.getElementById('rul').textContent = `${latest.rul_estimate.toFixed(0)} hrs`;
    document.getElementById('lastUpdate').textContent = formatTime(latest.timestamp);

    // Update VHI gauge
    updateGaugeChart(latest.vhi);

    // Update historical charts
    if (data.recent_data && data.recent_data.length > 0) {
        updateLineCharts(data.recent_data);
    }

    // Update alerts
    if (data.recent_alerts) {
        updateAlerts(data.recent_alerts);
    }
}

function updateSensorCard(valueId, barId, statusId, value, min, max, unit, threshold) {
    const el = document.getElementById(valueId);
    el.textContent = value.toFixed(2);

    // Calculate percentage for progress bar
    const percentage = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
    const barEl = document.getElementById(barId);
    barEl.style.width = percentage + '%';

    // Update status
    const statusEl = document.getElementById(statusId);
    if (value > threshold) {
        statusEl.textContent = 'Warning';
        statusEl.style.color = '#f59e0b';
    } else {
        statusEl.textContent = 'Normal';
        statusEl.style.color = '#10b981';
    }
}

function updateGaugeChart(vhi) {
    if (!dashboardState.charts.gauge) return;
    dashboardState.charts.gauge.data.datasets[0].data = [vhi, 100 - vhi];
    dashboardState.charts.gauge.update();
}

function updateLineCharts(recentData) {
    if (recentData.length === 0) return;

    // Limit to last N records
    const data = recentData.slice(-CHART_HISTORY).reverse();
    const timestamps = data.map(d => formatTime(d.timestamp));

    // Update Temperature Chart
    dashboardState.charts.temperature.data.labels = timestamps;
    dashboardState.charts.temperature.data.datasets[0].data = data.map(d => d.temperature);
    dashboardState.charts.temperature.update();

    // Update Vibration Chart
    dashboardState.charts.vibration.data.labels = timestamps;
    dashboardState.charts.vibration.data.datasets[0].data = data.map(d => d.vibration);
    dashboardState.charts.vibration.update();

    // Update Battery Chart
    dashboardState.charts.battery.data.labels = timestamps;
    dashboardState.charts.battery.data.datasets[0].data = data.map(d => d.battery_voltage);
    dashboardState.charts.battery.update();

    // Update VHI Chart
    dashboardState.charts.vhi.data.labels = timestamps;
    dashboardState.charts.vhi.data.datasets[0].data = data.map(d => d.vhi);
    dashboardState.charts.vhi.update();
}

function updateAlerts(alerts) {
    const alertsList = document.getElementById('alertsList');
    const alertHigh = document.getElementById('alertHigh');
    const alertMedium = document.getElementById('alertMedium');
    const alertLow = document.getElementById('alertLow');

    // Count alerts by severity
    let highCount = 0, mediumCount = 0, lowCount = 0;

    if (alerts.length === 0) {
        alertsList.innerHTML = '<p class="no-alerts">No active alerts</p>';
    } else {
        alertsList.innerHTML = alerts.map(alert => {
            const severity = alert.severity.toLowerCase();
            if (severity === 'high') highCount++;
            if (severity === 'medium') mediumCount++;
            if (severity === 'low') lowCount++;

            return `<div class="alert-item ${severity}">
                <strong>${alert.alert_type}</strong><br>
                ${alert.message}
            </div>`;
        }).join('');
    }

    alertHigh.textContent = highCount;
    alertMedium.textContent = mediumCount;
    alertLow.textContent = lowCount;
}

// ==================== TEST DATA SENDING ====================

function sendTestData() {
    const testData = {
        temperature: 85 + Math.random() * 20,
        vibration: 1.2 + Math.random() * 1.5,
        battery_voltage: 12.0 + Math.random() * 1,
        fuel_level: 50 + Math.random() * 40
    };

    console.log('Sending test data:', testData);

    fetch(`${API_BASE}/sensor-data`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(testData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Test data sent successfully');
            refreshData();
        } else {
            console.error('Error sending test data:', data.error);
        }
    })
    .catch(error => console.error('Error:', error));
}

// ==================== UTILITY FUNCTIONS ====================

function getHealthStatus(vhi) {
    if (vhi >= 80) return 'Excellent';
    if (vhi >= 60) return 'Good';
    if (vhi >= 40) return 'Fair';
    if (vhi >= 20) return 'Poor';
    return 'Critical';
}

function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit'
    });
}

function updateConnectionStatus(connected) {
    const statusLight = document.querySelector('.status-light');
    const statusText = document.getElementById('statusText');

    if (connected) {
        statusLight.classList.remove('offline');
        statusText.textContent = 'Connected';
        statusLight.style.background = '#10b981';
    } else {
        statusLight.classList.add('offline');
        statusText.textContent = 'Disconnected';
        statusLight.style.background = '#ef4444';
    }
}

function updateFooter() {
    const now = new Date();
    document.getElementById('footerTime').textContent = now.toLocaleTimeString('en-US');
    setTimeout(updateFooter, 1000);
}

// ==================== EVENT LISTENERS ====================

function setupEventListeners() {
    document.getElementById('refreshBtn').addEventListener('click', refreshData);
    document.getElementById('sendTestBtn').addEventListener('click', sendTestData);
}

// Auto-cleanup
window.addEventListener('beforeunload', function() {
    if (dashboardState.refreshInterval) {
        clearInterval(dashboardState.refreshInterval);
    }
});