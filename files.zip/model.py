"""
ML model interface for fault prediction.
Loads and uses the trained Random Forest model.
"""

import os
import joblib
import numpy as np


class FaultPredictionModel:
    """Wrapper for the fault prediction ML model."""
    
    # Prediction labels
    PREDICTION_LABELS = {
        0: 'Normal',
        1: 'Engine Overheating',
        2: 'Battery Issue',
        3: 'Abnormal Vibration'
    }
    
    def __init__(self, model_path='models/fault_prediction_model.pkl'):
        """
        Initialize model.
        
        Args:
            model_path (str): Path to trained model file
        """
        self.model_path = model_path
        self.model = None
        self.load_model()
    
    def load_model(self):
        """
        Load trained model from file.
        
        Returns:
            bool: True if model loaded successfully, False otherwise
        """
        if not os.path.exists(self.model_path):
            print(f"Warning: Model file not found at {self.model_path}")
            print("Run 'python train_model.py' to train the model first.")
            return False
        
        try:
            self.model = joblib.load(self.model_path)
            print(f"Model loaded successfully from {self.model_path}")
            return True
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            return False
    
    def predict(self, temperature, vibration, battery_voltage, fuel_level):
        """
        Predict vehicle fault condition.
        
        Args:
            temperature (float): Engine temperature in Celsius
            vibration (float): Vibration level in m/s²
            battery_voltage (float): Battery voltage in Volts
            fuel_level (float): Fuel level in percentage
        
        Returns:
            dict: Prediction results with label and confidence
        """
        if self.model is None:
            return {
                'success': False,
                'error': 'Model not loaded. Train the model first.'
            }
        
        try:
            # Prepare input
            X = np.array([[temperature, vibration, battery_voltage, fuel_level]])
            
            # Make prediction
            prediction = self.model.predict(X)[0]
            prediction_label = self.PREDICTION_LABELS.get(prediction, 'Unknown')
            
            # Get confidence scores
            probabilities = self.model.predict_proba(X)[0]
            confidence = float(np.max(probabilities))
            
            # Get all class probabilities
            class_probabilities = {
                self.PREDICTION_LABELS[i]: float(probabilities[i])
                for i in range(len(probabilities))
            }
            
            return {
                'success': True,
                'prediction': prediction,
                'prediction_label': prediction_label,
                'confidence': confidence,
                'class_probabilities': class_probabilities
            }
        
        except Exception as e:
            return {
                'success': False,
                'error': f'Prediction error: {str(e)}'
            }
    
    def get_model_info(self):
        """
        Get information about the loaded model.
        
        Returns:
            dict: Model information
        """
        if self.model is None:
            return {'status': 'Model not loaded'}
        
        return {
            'model_type': type(self.model).__name__,
            'n_estimators': self.model.n_estimators,
            'max_depth': self.model.max_depth,
            'n_classes': self.model.n_classes_,
            'feature_names': ['temperature', 'vibration', 'battery_voltage', 'fuel_level'],
            'class_labels': self.PREDICTION_LABELS
        }